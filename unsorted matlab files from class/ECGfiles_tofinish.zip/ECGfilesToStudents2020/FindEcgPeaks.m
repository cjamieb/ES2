function iPeaks = FindEcgPeaks(ecg,threshold)
% function iPeaks = FindEcgPeaks(ecg,threshold);
% find samples in input vector 'ecg' that are peaks,
% and are above the value 'threshold'

% your code (and name) here