function tvec = SetupTimeVector(npoints,Fs)
% function tvec = SetupTimeVector(npoints,Fs)
% returns a vector 'tvec' of times in seconds,
% of length npoints, starting at t=0 and 
% spaced apart by 1/Fs seconds

% your code (and name) here