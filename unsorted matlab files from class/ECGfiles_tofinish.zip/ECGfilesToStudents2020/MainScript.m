% MainScript
% calls the other functions, and plots results
% put answers to questions in this file!

% read in the data

% set up time vector

% find samples for all the peaks

% find instantanous HR

% find stats and set up output string

% plot the data, with peaks overlaid

% set up output filename, and save jpeg file
