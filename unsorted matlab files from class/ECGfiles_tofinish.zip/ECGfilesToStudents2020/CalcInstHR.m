function instBPM = CalcInstHR(tvec,iPk)
% function instBPM = CalcInstHR(tvec,iPk)
% given a time vector tvec and list of indices for peaks,
% returns a vector instBPM with the instantaneous beats per minute

% your code (and name) here!
