% MatrixFromNestedLoop
% week 8 lecture 1
clear; clc
% let's keep the distance here in terms of pixel #
n1 = 20;
n2 = 50;

cen1 = 11;
cen2 = 20;

% preallocate memory - important for matrices! Why?
dist = zeros(n1,n2);

% in other languages, this is THE typical way to fill a 
% 2-D array; also quite useful in Matlab
for ir = 1:n1
    for ic = 1:n2       
        dist(ir,ic) = sqrt((ir-cen1).^2 + (ic-cen2).^2);
    end
end

%% some different commands
figure,
subplot(221)
surf(dist)
xlabel('x'),ylabel('y'),zlabel('distance')
title('distance: surf command')
shading interp

subplot(222),
contour(dist)
title('distance: contour command')
% look at this too:  
% axis equal

subplot(223)
imagesc(dist)
colorbar
title('distance: imagesc & colorbar')

subplot(224),
contourf(dist)
xlabel('x'),ylabel('y')
title('distance: contourf command')


