
close all
clear
imgData = imread('cameraman.jpg');
figure,imagesc(imgData),caxis([0 255]),colorbar
colormap gray

figure,
surf(imgData)
shading interp
xlabel('x pix')
ylabel('y pix')
zlabel('pixel amplitude')


%% pull out a body part...
headImg = imgData(70:160,180:270);

figure,imagesc(headImg),colorbar

%% line cuts through the image
figure,
for irow = 50:10:512,
	plot(imgData(irow,:))
	ylim([0 255])
	xlim([0 512])
	grid
	titl=sprintf('Row # %d',irow);
	title(titl)
	xlabel('Pixel #')
	ylabel('Pixel value')
	boldify
	pause(0.05)
end

%% spinning head

tmp = headImg;
copyImg = imgData;
figure, 
for k=1:10
	%tmp = rot90(tmp); 
	tmp = tmp';
	copyImg(70:160,180:270)= tmp; 
	imagesc(copyImg) 
	colormap gray 
	pause(.2)
end


