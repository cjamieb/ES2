% displayColorImage

clear, clc

img= imread('teslaSide.JPG');
whos img

figure,
imagesc(img)
title('overall image')

figure
subplot(131)
imshow(img(:,:,1)),colormap gray
title('red image')
subplot(132)
imshow(img(:,:,2)),colormap gray
title('blue image')
subplot(133)
imshow(img(:,:,3)),colormap gray
title('green image')


% what is the biggest red value?
redChan = img(:,:,1);

max(max(redChan))

max(redChan(:))
min(redChan(:))