
% set up some notional RGB values for a pixel
val = [ 82 170 110];

plot3(val(1),val(2),val(3),'o','Markersize',10)
hold on
line([0 val(1)],[0 val(2)],[0 val(3)],'Linestyle',':')
axis([0 255 0 255 0 255])
grid on
xlabel('Red ')
ylabel('Green ')
zlabel('Blue ')

boldify